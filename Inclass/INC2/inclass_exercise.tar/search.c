#include "defs.h"
#include "buffer.h"
int search_function(){
return 0;
}
