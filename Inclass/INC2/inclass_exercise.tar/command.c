#include "defs.h"
#include "command.h"
int command_function(){
return 0;
}
